Instructions:

Download the project example data and place it into a folder named data.
Example:
├─data/
│ ├─cathedral.jpg
│ ├─...
└─main.ipynb

Run main.ipynb, which uses numpy, skimage, and tqdm.
I developed this project with Python 3.10.